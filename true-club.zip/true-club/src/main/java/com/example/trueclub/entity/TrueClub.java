package com.example.trueclub.entity;



import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.hibernate.annotations.CreationTimestamp;

import com.sun.istack.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "assignment")
@NoArgsConstructor
@AllArgsConstructor
public class TrueClub {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	 
	@NotBlank(message = "Name is mandatory")
	@Size(min=3, max=30)
	private String name;
	
	@NotBlank(message = "Address is mandatory")
	@Size(min=5, max=50)
	private String address;
	
	
	@NotNull
	private Integer pincode;
	
	
	@NotBlank(message = "State is mandatory")
	@Size(min=2, max=30)
	private String state;
	
	@CreationTimestamp
	@Column(name = "row_creation_timestamp", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date row_creation_timestamp;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Date getRow_creation_timestamp() {
		return row_creation_timestamp;
	}

	public void setRow_creation_timestamp(Date row_creation_timestamp) {
		this.row_creation_timestamp = row_creation_timestamp;
	}

	@Override
	public String toString() {
		return "TrueClub [id=" + id + ", name=" + name + ", address=" + address + ", pincode=" + pincode + ", state="
				+ state + ", row_creation_timestamp=" + row_creation_timestamp + "]";
	}
	
	
	
	
}
