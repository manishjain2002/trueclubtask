package com.example.trueclub.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.trueclub.entity.TrueClub;

@Repository
public interface TrueClubRepository extends JpaRepository<TrueClub, Long>{

	Optional<TrueClub> findByName(String name);

}
