package com.example.trueclub.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.trueclub.entity.TrueClub;
import com.example.trueclub.repository.TrueClubRepository;

@Service
public class TrueClubService {
	
	@Autowired 
	public TrueClubRepository trueclubrepository;

	public List<TrueClub> getAll() {
		return trueclubrepository.findAll();
	}

	public ResponseEntity<String> add(TrueClub trueClub) {
		Optional<TrueClub> tc=trueclubrepository.findByName(trueClub.getName());
		if(tc.isPresent()) {
			return new ResponseEntity<>("Already exits", HttpStatus.BAD_REQUEST);
		}else {
			trueclubrepository.save(trueClub);
		}
		return new ResponseEntity<>("Save Successful", HttpStatus.OK);
		
	}

	public TrueClub getTrueClub(Long id) {
		
		Optional<TrueClub> tc=trueclubrepository.findById(id);
		if(tc.isPresent()) {
			return tc.get();
		}
		return null;
		
	}

	public ResponseEntity<String> delete(Long id) {
		TrueClub tc=getTrueClub(id);
		if(tc==null) {
			return new ResponseEntity<>("Invalid Id", HttpStatus.NOT_FOUND);
		}
		trueclubrepository.delete(tc);
		return new ResponseEntity<>("Delete Successful", HttpStatus.OK);
	}

	public ResponseEntity<String> update(@Valid TrueClub trueClub) {
		Optional<TrueClub> tc=trueclubrepository.findByName(trueClub.getName());
		TrueClub tc1=getTrueClub(trueClub.getId());
		if(tc.isPresent()) {
			return new ResponseEntity<>("Already exits", HttpStatus.BAD_REQUEST);
		}else if(tc1!=null){
			TrueClub newtc=new TrueClub();
			newtc.setId(trueClub.getId());
			newtc.setAddress(trueClub.getAddress());
			newtc.setName(trueClub.getName());
			newtc.setPincode(trueClub.getPincode());
			newtc.setState(trueClub.getState());
			newtc.setRow_creation_timestamp(tc1.getRow_creation_timestamp());
			
			trueclubrepository.save(newtc);
		}else {
			return new ResponseEntity<>("Not Found", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>("Update Successful", HttpStatus.OK);
	}
	
	

}
