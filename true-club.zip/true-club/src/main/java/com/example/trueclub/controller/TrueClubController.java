package com.example.trueclub.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.trueclub.entity.TrueClub;
import com.example.trueclub.service.TrueClubService;

@RestController
@CrossOrigin
@RequestMapping("/trueclub")
public class TrueClubController {
	
	@Autowired
	public TrueClubService trueclubservice;
	
	@GetMapping("/all")
	public List<TrueClub> getAll(){
		return trueclubservice.getAll();
	}
	
	@GetMapping("/get/{id}")
	public TrueClub getTrueClub(@PathVariable("id") Long id){
		return trueclubservice.getTrueClub(id);
	}
	
	@GetMapping("/delete/{id}")
	public ResponseEntity<String> delete(@PathVariable("id") Long id){
		return trueclubservice.delete(id);
	}
	
	@GetMapping("/hello")
	public String hello(){
		return "Hello World";
	}
	
	@PostMapping("/add")
	public ResponseEntity<String> addTrueClub(@Valid @RequestBody TrueClub trueClub) {
		return trueclubservice.add(trueClub);
	}
	
	@PostMapping("/update")
	public ResponseEntity<String> update(@Valid @RequestBody TrueClub trueClub) {
		return trueclubservice.update(trueClub);
	}
	
	

}
